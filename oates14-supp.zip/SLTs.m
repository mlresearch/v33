% This function implements SLTs for the 3-tier examples presented in the accompanying paper. The likelihood is based on dynamic Bayesian networks with interventions, as described in the paper.
%
% INPUTS:
% D{i,j,c} = data matrix for G_1ij and time series c, in the format variables x time
% IV{i,j} = binary matrix encoding targets of interventions for G_1ij in the format variables x time series (true = intervention, false = no intervention)
% dmax = in-degree restriction
% G0 = prior network
%
% OUTPUTS:
% G = weighted adjacency matrix of posterior inclusion probabilities for the latent network G_1.
% Gi = cell(I,1); Gi{i} = weighted adjacency matrix of posterior inclusion probabilities for latent network G_1i.
% Gij = cell(I,J); Gij{i,j} = weighted adjacency matrix of posterior inclusion probabilities for data-generating network G_1ij.
% For adjacency matrices, rows correspond to parents and columns correspond to children.

function [G,Gi,Gij] = SLTs(D,IV,dmax,G0)

%%%%%%%%%%%%%%%%%%%%
% Check dimensions %
%%%%%%%%%%%%%%%%%%%%
I = size(D,1);
J = size(D,2);
C = size(D,3);
[P,n] = size(D{1,1,1});

%%%%%%%%%%
% Output %
%%%%%%%%%%
G = zeros(P);
Gi = cell(I,1);
Gij = cell(I,J);
for i = 1:I
    Gi{i} = zeros(P);
    for j = 1:J
        Gij{i,j} = zeros(P);
    end
end

%%%%%%%%%%%%%%%%%%%%
% Enumerate models %
%%%%%%%%%%%%%%%%%%%%
% number of possible parent sets
n_models = 0;
for i=0:dmax
    n_models = n_models + nchoosek(P,i);
end
% calculate all parent sets
models = false(P,n_models);
counter = 0;
for d = 0:dmax
    nck = nchoosek(1:P,d);
    for i = 1:size(nck,1);
        counter = counter + 1;
        for j = 1:size(nck,2)
            models(nck(i,j),counter) = true;
        end
    end
end
M = size(models,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute and cache marginal likelihoods p(y_p^{ij}|G_p^{ij}) %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
MLs = zeros(P,I,J,M);
lMLs = zeros(P,I,J,M);
for i = 1:I
    for j = 1:J
        for m = 1:M           
            % Build design matrix for G_1ij, model m.
            % All experimental data enters the design matrix.
            num_prot = sum(models(:,m));
            DT = sum(IV{i,j}(models(:,m),:),2)>0; % targets of intervention, over all time series
            X0 = []; Xm = []; y = []; 
            for c = 1:C
                X0c = [1 zeros(1,n-1); ones(1,n)]'; % or [1 zeros(1,n-1); 0 ones(1,n-1)]' but improper prior so the same
                yc = D{i,j,c};
                Xmc = [zeros(1,num_prot); D{i,j,c}(models(:,m),1:end-1)']; 
                % Fixed effect, perfect out interventions:
                DT_c = IV{i,j}(models(:,m),c); % intervention targets in time series c
                n_DT_c = sum(DT_c); % num. targets in series c
                Xmc(:,DT_c) = nan(n,n_DT_c);
                Xmc = [Xmc repmat(DT_c(DT)',n,1)];
                X0 = [X0; X0c];
                Xm = [Xm; Xmc]; 
                y = [y yc];
            end       
            P0 = X0*pinv(X0); %P0 = X0*((X0'*X0)\(X0'));
            %%%%% model complexity
            [N,a] = size(X0);
            %b = num_prot; % rather than b = size(Xm,2); % model complexity                
            b = size(Xm,2);
            %%%%% Degenerate case where e.g. a predictor is inhibited in all experiments
            ix = or((std(Xm,0,1)==0),(sum(~isnan(Xm),1)==0)); % indices of columns containing no variation
            if sum(ix)>0
                Xm = Xm(:,~ix); % remove problem column(s)         
            end        
            %%%%% Orthogonalisation
            % An extension of Xm = (eye(N)-P0)*Xm; which preserves zeros:
            for p = 1:size(Xm,2)
                wh = (~isnan(Xm(:,p)));
                Xm(wh,p) = (eye(sum(wh)) - X0(wh,:)*pinv(X0(wh,:)))*Xm(wh,p);
            end
            Xm(isnan(Xm)) = 0;
            %%%%%
            Pm = Xm*pinv(Xm); %Pm = Xm*((Xm'*Xm)\(Xm'));            
            for p = 1:P     
                % classical Zellner
                g = N;
                err = y(p,:)*((eye(N)-P0-g*Pm/(g+1))*(y(p,:)'));
                %MLs(p,i,j,m) = (1/2) * gamma((N-a)/2) * pi^(-(N-a)/2) ...
                %              * det(X0'*X0)^(-1) * (g+1)^(-b/2) ...
                %              * err^(-(N-a)/2);                                 
                
                lMLs(p,i,j,m) = -(b/2)*log(g+1) - ((N-a)/2)*log(err);                                 
                
            end            
        end
    end
end

% Numerical stability:
for p = 1:P
    for i = 1:I
        for j = 1:J
            lMLs(p,i,j,:) = lMLs(p,i,j,:) - max(squeeze(lMLs(p,i,j,:)));
        end
    end
end
MLs = exp(lMLs);

if sum(isnan(MLs(:)))>0
    error('nan')
end

% p(G_p^{ij}|G_p^i)
PP1 = cell(P,I,J); 
for p = 1:P
    for i = 1:I
        for j = 1:J
            PP1{p,i,j} = sparse(M,M);
            for m1 = 1:M
                for m2 = 1:M
                    ix = sum((models(:,m1) - models(:,m2))==1)>0;
                    if ~ ix
                        k = sum(models(:,m1));
                        PP1{p,i,j}(m1,m2) = 1 / max(1,nchoosek(P,k));
                    end
                end
            end
        end
    end
end
% p(G_p^i|G_p)
PP2 = cell(P,I); 
for p = 1:P
    for i = 1:I
        PP2{p,i} = sparse(M,M);
        for m1 = 1:M
            for m2 = 1:M
                ix = sum((models(:,m1) - models(:,m2))==1)>0;
                if ~ ix
                    k = sum(models(:,m1));
                    PP2{p,i}(m1,m2) = 1 / max(1,nchoosek(P,k));
                end
            end
        end
    end
end 
% p(G_p|G_p^0)
PP3 = zeros(P,M); 
for p = 1:P
    for m = 1:M  
        ix = sum((models(:,m) - G0(:,p))==1)>0;
        if ix
            PP3(p,m) = 0;
        else
            k = sum(models(:,m));
            PP3(p,m) = 1 / max(1,nchoosek(P,k));
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Perform belief propagation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Below, step numbers correspond to Alg. 1 in the paper.
for p = 1:P
    % STEP 4
    STEP4 = zeros(I,J,M);
    for i = 1:I
        for j = 1:J
            for m = 1:M                
                STEP4(i,j,m) = squeeze(PP1{p,i,j}(:,m))' * squeeze(MLs(p,i,j,:));   
            end
            STEP4(i,j,:) = STEP4(i,j,:) / max(STEP4(i,j,:));
        end
    end
    
    if sum(isnan(STEP4(:)))>0
        error('nan')
    end
    if sum(STEP4(:)==0)>0
        disp('zero1')
    end
    
    % STEP 5
    STEP5 = zeros(I,M);
    for i = 1:I
        lSTEP5 = zeros(1,M);
        for m = 1:M
            %STEP5(i,m) = prod(squeeze(STEP4(i,:,m))); 
            lSTEP5(m) = sum(log(squeeze(STEP4(i,:,m))));
        end
        %STEP5(i,:) = STEP5(i,:) / max(STEP5(i,:));
        lSTEP5 = lSTEP5 - max(lSTEP5);
        STEP5(i,:) = exp(lSTEP5);
    end
    
    if sum(isnan(STEP5(:)))>0
        error('nan')
    end
    if sum(STEP5(:)==0)>0
        disp('zero2')
    end
    
    % STEP 6
    STEP6 = zeros(I,M);
    for i = 1:I
        for m = 1:M      
            STEP6(i,m) = squeeze(PP2{p,i}(:,m))' * STEP5(i,:)';
        end
        STEP6(i,:) = STEP6(i,:) / max(STEP6(i,:));
    end 
    
    if sum(isnan(STEP6(:)))>0
        error('nan')
    end
    if sum(isinf(STEP6(:)))>0
        error('inf')
    end
    if sum(STEP6(:)==0)>0
        disp('zero3')
    end
    
    % STEP 7
    STEP7 = zeros(M,1);
    STEP7_max = 0;
    for m = 1:M
        STEP7(m) = PP3(p,m);
        STEP7_max = max(STEP7(m),STEP7_max);
    end
    STEP7 = STEP7 / STEP7_max;
    
    if sum(isnan(STEP7(:)))>0
        error('nan')
    end
    if sum(isinf(STEP7(:)))>0
        error('inf')
    end
    if sum(STEP7(:)==0)>0
        disp('zero4')
    end
    
    % STEP 8
    STEP8 = zeros(I,M);
    STEP8_max = 0;
    for i = 1:I
        ix = true(1,I); ix(i) = false;
        for m = 1:M
            STEP8(i,m) = STEP7(m) * prod(STEP6(ix,m));
            STEP8_max = max(STEP8(i,m),STEP8_max);
        end
    end
    STEP8 = STEP8 / STEP8_max;
    
    if sum(isnan(STEP8(:)))>0
        error('nan')
    end
    if sum(STEP8(:)==0)>0
        disp('zero5')
    end
    
    % STEP 9
    STEP9 = zeros(I,M);
    STEP9_max = 0;
    for i = 1:I
        for m = 1:M
            STEP9(i,m) = squeeze(PP2{p,i}(m,:)) * STEP8(i,:)';
            STEP9_max = max(STEP9(i,m),STEP9_max);
        end
    end
    STEP9 = STEP9 / STEP9_max;
    
    if sum(isnan(STEP9(:)))>0
        error('nan')
    end
    if sum(STEP9(:)==0)>0
        disp('zero6')
    end
    
    % STEP 10
    STEP10 = zeros(I,J,M);
    STEP10_max = 0;
    for i = 1:I
        for j = 1:J
            for m = 1:M
                STEP10(i,j,m) = STEP9(i,m);
                STEP10_max = max(STEP10(i,j,m),STEP10_max);
            end
        end
    end
    STEP10 = STEP10 / STEP10_max;
    
    if sum(isnan(STEP10(:)))>0
        error('nan')
    end
    if sum(STEP10(:)==0)>0
        disp('zero7')
    end
    
    % STEP 11
    STEP11 = zeros(I,J,M);
    STEP11_max = 0;
    for i = 1:I
        for j = 1:J
            for m = 1:M
                STEP11(i,j,m) = squeeze(PP1{p,i,j}(m,:)) * squeeze(STEP10(i,j,:));  
                STEP11_max = max(STEP11(i,j,m),STEP11_max);
            end
        end
    end
    STEP11 = STEP11 / STEP11_max;
    
    if sum(isnan(STEP11(:)))>0
        error('nan')
    end
    if sum(STEP11(:)==0)>0
        disp('zero8')
    end
    
    % Marginal p(G|y)
    M1 = zeros(M,1);
    for m = 1:M
        M1(m) = STEP7(m) * prod(STEP6(:,m));
    end    
    M1 = M1 / sum(M1);
    
    if sum(isnan(M1(:)))>0
        error('nan')
    end
    
    % Marginal p(G^i|y)
    M2 = zeros(I,M);
    for i = 1:I
        for m = 1:M
            M2(i,m) = STEP9(i,m) * prod(squeeze(STEP4(i,:,m)));
        end
        M2(i,:) = M2(i,:) / sum(M2(i,:));
    end
    
    if sum(isnan(M2(:)))>0
        error('nan')
    end
    
    % Marginal p(G^ij|y)
    M3 = zeros(I,J,M);
    for i = 1:I
        for j = 1:J
            for m = 1:M
                M3(i,j,m) = STEP11(i,j,m) * MLs(p,i,j,m);
            end
            M3(i,j,:) = M3(i,j,:) / sum(M3(i,j,:));
        end
    end
       
    if sum(isnan(M3(:)))>0
        error('nan')
    end

    %%%%%%%%%%%%%%%%%%%
    % Model averaging %
    %%%%%%%%%%%%%%%%%%%
    G(:,p) = models * M1;
    for i = 1:I
        Gi{i}(:,p) = models * M2(i,:)';
        for j = 1:J
            Gij{i,j}(:,p) = models * squeeze(M3(i,j,:));
        end
    end 
end

end






